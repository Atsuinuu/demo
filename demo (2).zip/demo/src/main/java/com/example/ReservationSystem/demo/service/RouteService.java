package com.example.ReservationSystem.demo.service;

import com.example.ReservationSystem.demo.model.Route;
import com.example.ReservationSystem.demo.repository.RouteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Optional;

@Service
public class RouteService {

    @Autowired
    private RouteRepository routeRepository;

    // Get all routes
    public List<Route> getAllRoutes() {
        return routeRepository.findAll();
    }

    // Get route by ID
    public ResponseEntity<Route> getRouteById(Long id) {
        Optional<Route> route = routeRepository.findById(id);
        return route.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Create a new route
    public Route createRoute(Route route) {
        return routeRepository.save(route);
    }

    // Update an existing route
    public ResponseEntity<Route> updateRoute(Long id, Route routeDetails) {
        Optional<Route> existingRoute = routeRepository.findById(id);
        if (existingRoute.isPresent()) {
            Route route = existingRoute.get();
            route.setStartLocation(routeDetails.getStartLocation());
            route.setEndLocation(routeDetails.getEndLocation());
            route.setDistance(routeDetails.getDistance());
            return ResponseEntity.ok(routeRepository.save(route));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Delete a route
    public ResponseEntity<Void> deleteRoute(Long id) {
        Optional<Route> route = routeRepository.findById(id);
        if (route.isPresent()) {
            routeRepository.delete(route.get());
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}

