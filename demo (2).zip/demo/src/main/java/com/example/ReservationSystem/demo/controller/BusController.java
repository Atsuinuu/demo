package com.example.ReservationSystem.demo.controller;

import com.example.ReservationSystem.demo.model.Bus;
import com.example.ReservationSystem.demo.repository.BusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bus")
public class BusController {

    @Autowired
    private BusRepository busRepository;

    // API Endpoint to get all buses
    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('STAFF')")
    public List<Bus> getAllBuses() {
        return busRepository.findAll();
    }

    // Thymeleaf view to display all buses
    @GetMapping("/view")
    @PreAuthorize("hasRole('ADMIN') or hasRole('STAFF')")
    public String getAllBusesForView(Model model) {
        List<Bus> buses = busRepository.findAll();
        model.addAttribute("buses", buses);
        return "bus-list";  // Corresponds to bus-list.html template
    }

    // API Endpoint to get bus by ID
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('STAFF')")
    public ResponseEntity<Bus> getBusById(@PathVariable Long id) {
        return busRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Thymeleaf view to display bus by ID
    @GetMapping("/view/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('STAFF')")
    public String getBusByIdForView(@PathVariable Long id, Model model) {
        return busRepository.findById(id)
                .map(bus -> {
                    model.addAttribute("bus", bus);
                    return "bus-details";  // Corresponds to bus-details.html template
                })
                .orElse("error"); // Error page if bus not found
    }

    // API Endpoint to create a new bus (REST API)
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Bus createBusAPI(@RequestBody Bus bus) {
        return busRepository.save(bus);
    }

    // Thymeleaf form to create a new bus
    @GetMapping("/create")
    @PreAuthorize("hasRole('ADMIN')")
    public String createBusForm() {
        return "create-bus";  // Corresponds to create-bus.html template
    }

    @PostMapping("/create")
    @PreAuthorize("hasRole('ADMIN')")
    public String createBus(@ModelAttribute Bus bus) {
        busRepository.save(bus);
        return "redirect:/bus/view";  // Redirect to bus list page after creating a new bus
    }

    // API Endpoint to update an existing bus
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Bus> updateBus(@PathVariable Long id, @RequestBody Bus busDetails) {
        return busRepository.findById(id)
                .map(bus -> {
                    bus.setBusNumber(busDetails.getBusNumber());
                    bus.setCapacity(busDetails.getCapacity());
                    bus.setRoute(busDetails.getRoute());
                    bus.setSchedule(busDetails.getSchedule());
                    return ResponseEntity.ok(busRepository.save(bus));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // Thymeleaf form to edit an existing bus
    @GetMapping("/edit/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String editBusForm(@PathVariable Long id, Model model) {
        return busRepository.findById(id)
                .map(bus -> {
                    model.addAttribute("bus", bus);
                    return "edit-bus";  // Corresponds to edit-bus.html template
                })
                .orElse("error"); // Error page if bus not found
    }

    @PostMapping("/edit/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String editBus(@PathVariable Long id, @ModelAttribute Bus busDetails) {
        return busRepository.findById(id)
                .map(bus -> {
                    bus.setBusNumber(busDetails.getBusNumber());
                    bus.setCapacity(busDetails.getCapacity());
                    bus.setRoute(busDetails.getRoute());
                    bus.setSchedule(busDetails.getSchedule());
                    busRepository.save(bus);
                    return "redirect:/bus/view";  // Redirect to bus list page after update
                })
                .orElse("error"); // Error page if bus not found
    }

    // API Endpoint to delete a bus
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteBus(@PathVariable Long id) {
        return busRepository.findById(id)
                .map(bus -> {
                    busRepository.delete(bus);
                    return ResponseEntity.noContent().<Void>build();
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // Thymeleaf page to confirm deletion of a bus
    @GetMapping("/delete/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String deleteBusConfirmationPage(@PathVariable Long id, Model model) {
        return busRepository.findById(id)
                .map(bus -> {
                    model.addAttribute("bus", bus);
                    return "delete-bus";  // Corresponds to delete-bus.html template
                })
                .orElse("error"); // Error page if bus not found
    }

    // Perform the deletion from the confirmation page
    @PostMapping("/delete/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String performDeleteBus(@PathVariable Long id) {
        return busRepository.findById(id)
                .map(bus -> {
                    busRepository.delete(bus);
                    return "redirect:/bus/view";  // Redirect to bus list page after deletion
                })
                .orElse("error"); // Error page if bus not found
    }
}
