package com.example.ReservationSystem.demo.service;

import com.example.ReservationSystem.demo.model.Passenger;
import com.example.ReservationSystem.demo.repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Optional;

@Service
public class PassengerService {

    @Autowired
    private PassengerRepository passengerRepository;

    // Get all passengers
    public List<Passenger> getAllPassengers() {
        return passengerRepository.findAll();
    }

    // Get passenger by ID
    public ResponseEntity<Passenger> getPassengerById(Long id) {
        Optional<Passenger> passenger = passengerRepository.findById(id);
        return passenger.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Create a new passenger
    public Passenger createPassenger(Passenger passenger) {
        return passengerRepository.save(passenger);
    }

    // Update an existing passenger
    public ResponseEntity<Passenger> updatePassenger(Long id, Passenger passengerDetails) {
        Optional<Passenger> existingPassenger = passengerRepository.findById(id);
        if (existingPassenger.isPresent()) {
            Passenger passenger = existingPassenger.get();
            passenger.setName(passengerDetails.getName());
            passenger.setEmail(passengerDetails.getEmail());
            passenger.setPhoneNumber(passengerDetails.getPhoneNumber());
            return ResponseEntity.ok(passengerRepository.save(passenger));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Delete a passenger
    public ResponseEntity<Void> deletePassenger(Long id) {
        Optional<Passenger> passenger = passengerRepository.findById(id);
        if (passenger.isPresent()) {
            passengerRepository.delete(passenger.get());
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
