package com.example.ReservationSystem.demo.service;

import com.example.ReservationSystem.demo.model.Bus;
import com.example.ReservationSystem.demo.repository.BusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Optional;

@Service
public class BusService {

    @Autowired
    private BusRepository busRepository;

    // Get all buses
    public List<Bus> getAllBuses() {
        return busRepository.findAll();
    }

    // Get bus by ID
    public ResponseEntity<Bus> getBusById(Long id) {
        Optional<Bus> bus = busRepository.findById(id);
        return bus.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Create a new bus
    public Bus createBus(Bus bus) {
        return busRepository.save(bus);
    }

    // Update an existing bus
    public ResponseEntity<Bus> updateBus(Long id, Bus busDetails) {
        Optional<Bus> existingBus = busRepository.findById(id);
        if (existingBus.isPresent()) {
            Bus bus = existingBus.get();
            bus.setBusNumber(busDetails.getBusNumber());
            bus.setCapacity(busDetails.getCapacity());
            bus.setRoute(busDetails.getRoute());
            bus.setSchedule(busDetails.getSchedule());
            return ResponseEntity.ok(busRepository.save(bus));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Delete a bus
    public ResponseEntity<Void> deleteBus(Long id) {
        Optional<Bus> bus = busRepository.findById(id);
        if (bus.isPresent()) {
            busRepository.delete(bus.get());
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}

