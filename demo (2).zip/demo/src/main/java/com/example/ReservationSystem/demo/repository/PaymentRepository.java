package com.example.ReservationSystem.demo.repository;


import com.example.ReservationSystem.demo.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
}
