package com.example.ReservationSystem.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf
                        .ignoringRequestMatchers("/api/**")) // Disable CSRF for all /api/** endpoints (including /bus, /route, and /reservations)
                .authorizeHttpRequests(auth -> auth
                        // Set permissions based on roles for different endpoints
                        .requestMatchers("/bus/**", "/route/**").hasRole("ADMIN") // Only ADMIN can access /bus and /route endpoints
                        .requestMatchers("/reservations/**").hasAnyRole("ADMIN", "STAFF") // Only ADMIN and STAFF can access /reservations
                        .requestMatchers("/reservations/client/**").hasRole("CLIENT") // Only CLIENT can access /reservations/client
                        .requestMatchers("/login").permitAll() // Allow all users to access the login page
                        .anyRequest().authenticated() // All other endpoints require authentication
                )
                .formLogin(formLogin -> formLogin
                        .loginPage("/login") // Custom login page
                        .defaultSuccessUrl("/home", true) // Redirect users to /home after successful login
                        .permitAll() // Allow everyone to access the login page
                )
                .logout(logout -> logout
                        .logoutUrl("/logout") // Set logout URL
                        .logoutSuccessUrl("/login?logout") // Redirect to login page after logout
                        .permitAll()); // Allow everyone to access the logout page

        return http.build();
    }

    @Bean
    public UserDetailsService userDetailsService() {
        // Define users with roles and encoded passwords
        UserDetails admin = User.withUsername("admin")
                .password(passwordEncoder().encode("adminpass"))
                .roles("ADMIN") // Role: ADMIN
                .build();

        UserDetails staff = User.withUsername("staff")
                .password(passwordEncoder().encode("staffpass"))
                .roles("STAFF") // Role: STAFF
                .build();

        UserDetails client = User.withUsername("client")
                .password(passwordEncoder().encode("clientpass"))
                .roles("CLIENT") // Role: CLIENT
                .build();

        return new InMemoryUserDetailsManager(admin, staff, client);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(); // Use BCrypt for secure password encoding
    }
}
