package com.example.ReservationSystem.demo.repository;

import com.example.ReservationSystem.demo.model.Bus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BusRepository extends JpaRepository<Bus, Long> {
}

